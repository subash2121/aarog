package com.vinithra.aarogg

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
