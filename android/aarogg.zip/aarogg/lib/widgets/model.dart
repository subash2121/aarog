import 'package:flutter/material.dart';
class Model {
  String firstName;
  int age;
  String bloodgroup;
  String address;
  int contact;
  Model({this.firstName, this.age, this.bloodgroup, this.address,this.contact});
}