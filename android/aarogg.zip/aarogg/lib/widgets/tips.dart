class Tips{
 List tips=["Do you know sleep and immunity are closely tied? Hope u had a peaceful sleep yesterday",
   "Whether it comes on quick or builds over time, it's important to understand how stress affects your health — including the impact it has on your immune system. Try to Minimize your stress.",
   "Feeding your body certain foods may help keep your immune system strong.Plan your diet with powerful immunity boosters.",
   "A good laugh and a long sleep are the best cures in the doctor’s book.",
   "Watch your diet-Eighty percent of your immune system is in the gut, so when it's healthy, we tend to be able to fight off infections faster and better.",
   "Early to bed and early to rise, makes a man healthy wealthy and wise.",
   "The best and most efficient pharmacy is within your own system.",
   "Water is your friend-Make sure u drink at least 2 litre of water everyday.",
   "Eat your stress away. Prevent low blood sugar as it stresses you out. Eat regular and small healthy meals and keep fruit and veggies handy. Herbal teas will also soothe your frazzled nerves.",
   "Vitamin D has numerous effects on cells within the immune system. It inhibits B cell proliferation and blocks B cell differentiation and immunoglobulin secretion",
   "U can't 'get' wealth if U R not in good health. Health is Wealth – Keep this treasure Safe.",
   "Up for a little adventure? - can u minimize ur junk food to only twice a week?",
   "Without health, Life is almost dead! A healthy body holds a Healthy Soul & mind!",
   "Lower the sugar intake.Added sugars contribute significantly to obesity, type 2 diabetes, and heart disease, all of which can suppress your immune system.",
   "Those who do not find time for exercise will have to find time for illness.",
   "Don’t be mean, Eat your beans. Eat your greens to fit into your jeans.",
   "Stop feeding your body garbage or else you will live for less age.",
   "H3 should be your life mantra , Health , Happiness and harmony.",
   "To eat is a necessity but to eat healthy is an art.",
   "Alcohol is your choice today then medicines will be your only option tomorrow."];

}